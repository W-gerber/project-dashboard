import React from 'react';

    function Login() {
      return (
        <div>
          <h1 className="text-3xl font-bold mb-4">Login</h1>
          {/* Add login form here */}
        </div>
      );
    }

    export default Login;
